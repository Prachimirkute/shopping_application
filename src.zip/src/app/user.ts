export class User {
    id:number | undefined;
    emailid!: string;
    name!: string;
    password!: string;
    constructor(){}
    // constructor(id:number,emailid:string,name:string,password:string){
    //     this.id = id;
    //     this.emailid= emailid;
    //     this.name = name;
    //     this.password = password;
    // }
}
